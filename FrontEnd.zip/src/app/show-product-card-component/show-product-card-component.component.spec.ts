import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowProductCardComponentComponent } from './show-product-card-component.component';

describe('ShowProductCardComponentComponent', () => {
  let component: ShowProductCardComponentComponent;
  let fixture: ComponentFixture<ShowProductCardComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ShowProductCardComponentComponent]
    });
    fixture = TestBed.createComponent(ShowProductCardComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
