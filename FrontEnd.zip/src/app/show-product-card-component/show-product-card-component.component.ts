import { Component } from '@angular/core';
import { productList } from 'src/app/data/data-mocks/productList';

@Component({
  selector: 'app-show-product-card-component',
  templateUrl: './show-product-card-component.component.html',
  styleUrls: ['./show-product-card-component.component.scss']
})
export class ShowProductCardComponentComponent {
  productList = productList;



  goToProductDetail(id: number){
    window.location.href ='product-detail/' + id;
  }
}
