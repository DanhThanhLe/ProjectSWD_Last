import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/data/data-mocks/data-modal/product';
import { productList } from 'src/app/data/data-mocks/productList';

@Component({
  selector: 'app-product-detail-component',
  templateUrl: './product-detail-component.component.html',
  styleUrls: ['./product-detail-component.component.scss']
})
export class ProductDetailComponentComponent {

  public product?: Product;
  constructor(
    private route: ActivatedRoute,
  ){}
  ngOnInit() {
    this.getProductById();
  }
  getProductById(): void {
    let productId = Number(this.route.snapshot.paramMap.get('id'));
    this.product = productList.find(({id})=> id === productId);
  }
}
