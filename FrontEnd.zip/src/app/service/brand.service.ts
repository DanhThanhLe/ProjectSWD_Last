import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BrandService {
  private baseUrl = 'https://localhost:7070/';
  constructor( private http: HttpClient) { }
  
  getBrandList(): Observable<any> {
  
    return this.http.get(`${this.baseUrl}`+'GetAllBrands');
  }
  
  getBrandById(id: String): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'GetBrandById/'+`${id}`);
  }
  // updateProduct(id: String, value: any): Observable<Object> {
  //   return this.http.put(`${this.baseUrl}`+'UpdateProduct/' +`${id}`, value);
  // }
  
}
