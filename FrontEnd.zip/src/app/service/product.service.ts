import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductModal } from '../data/data-mocks/data-modal/product-modal';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl = 'https://localhost:7070/api/Product/';
  constructor( private http: HttpClient) { }
  
  getProductsList(): Observable<any> {
  
    return this.http.get(`${this.baseUrl}`+'GetAllProducts');
  }
  
  getProductById(id: String): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'GetProductById/'+`${id}`);
  }
  updateProduct(id: String, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}`+'UpdateProduct/' +`${id}`, value);
  }
  
}
