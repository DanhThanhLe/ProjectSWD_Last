import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { images } from '../data/data-mocks/images';
interface EventItem {
  status?: string;
  date?: string;
  description?: string,
  icon?: string;
  color?: string;
  image?: string;
}
@Component({
  selector: 'app-home-page-component',
  templateUrl: './home-page-component.component.html',
  styleUrls: ['./home-page-component.component.scss']
})
export class HomePageComponentComponent {
  items: MenuItem[] | undefined;

  activeItem: MenuItem | undefined;
  images!: any[];
  events!: EventItem[];

  responsiveOptions: any[] = [
    {
      breakpoint: '1024px',
      numVisible: 5
    },
    {
      breakpoint: '768px',
      numVisible: 3
    },
    {
      breakpoint: '560px',
      numVisible: 1
    }
  ];

  constructor( ) {
    this.events = [
      {
        status: 'Ordered', date: '15/10/2020 10:30', description: 'Để duy trì khả năng vận hành tối ưu, một chiếc xe thể thao cần sự chăm sóc và bảo dưỡng thường xuyên. Thấu hiểu rằng không phải tất cả Quý khách đều thuận tiện để đến các trung tâm Porsche, chúng tôi tiếp tục triển khai dịch vụ Bảo dưỡng lưu động trong năm 2023 tại một số khu vực trên toàn quốc. Kỹ thuật viên được chứng nhận bởi Porsche sẽ chăm sóc và thực hiện các dịch vụ cho xe, từ bảo dưỡng định kỳ đến các sữa chữa khác theo yêu cầu nhằm mang lại cho Quý khách trải nghiệm dịch vụ chuyên nghiệp theo tiêu chuẩn tại các trung tâm Porsche.',
        icon: 'pi pi-shopping-cart', color: '#9C27B0', image: '../../assets/event_order.jpg'
      },
      {
        status: 'Payment', date: '15/10/2020 14:00', description: 'Để duy trì khả năng vận hành tối ưu, một chiếc xe thể thao cần sự chăm sóc và bảo dưỡng thường xuyên. Thấu hiểu rằng không phải tất cả Quý khách đều thuận tiện để đến các trung tâm Porsche, chúng tôi tiếp tục triển khai dịch vụ Bảo dưỡng lưu động trong năm 2023 tại một số khu vực trên toàn quốc. Kỹ thuật viên được chứng nhận bởi Porsche sẽ chăm sóc và thực hiện các dịch vụ cho xe, từ bảo dưỡng định kỳ đến các sữa chữa khác theo yêu cầu nhằm mang lại cho Quý khách trải nghiệm dịch vụ chuyên nghiệp theo tiêu chuẩn tại các trung tâm Porsche.',
        icon: 'pi pi-paypal', color: '#673AB7', image: '../../assets/payment_event.png'
      },
      {
        status: 'Shipment', date: '15/10/2020 16:15', description: 'Để duy trì khả năng vận hành tối ưu, một chiếc xe thể thao cần sự chăm sóc và bảo dưỡng thường xuyên. Thấu hiểu rằng không phải tất cả Quý khách đều thuận tiện để đến các trung tâm Porsche, chúng tôi tiếp tục triển khai dịch vụ Bảo dưỡng lưu động trong năm 2023 tại một số khu vực trên toàn quốc. Kỹ thuật viên được chứng nhận bởi Porsche sẽ chăm sóc và thực hiện các dịch vụ cho xe, từ bảo dưỡng định kỳ đến các sữa chữa khác theo yêu cầu nhằm mang lại cho Quý khách trải nghiệm dịch vụ chuyên nghiệp theo tiêu chuẩn tại các trung tâm Porsche.',
        icon: 'pi pi-car', color: '#FF9800', image: '../../assets/shipment_event.png'
      },
      {
        status: 'Delivered', date: '16/10/2020 10:00', description: 'Để duy trì khả năng vận hành tối ưu, một chiếc xe thể thao cần sự chăm sóc và bảo dưỡng thường xuyên. Thấu hiểu rằng không phải tất cả Quý khách đều thuận tiện để đến các trung tâm Porsche, chúng tôi tiếp tục triển khai dịch vụ Bảo dưỡng lưu động trong năm 2023 tại một số khu vực trên toàn quốc. Kỹ thuật viên được chứng nhận bởi Porsche sẽ chăm sóc và thực hiện các dịch vụ cho xe, từ bảo dưỡng định kỳ đến các sữa chữa khác theo yêu cầu nhằm mang lại cho Quý khách trải nghiệm dịch vụ chuyên nghiệp theo tiêu chuẩn tại các trung tâm Porsche.',
        icon: 'pi pi-check', color: '#607D8B', image: '../../assets/delivery_event.png'
      }
    ];
  }


  ngOnInit() {
   
    this.items = [
      { label: 'Home', icon: 'pi pi-fw pi-home', command:() => this.gotoHome() },
      { label: 'List Products', icon: 'pi pi-fw pi-align-justify', command:() => this.gotoList() },
      { label: 'List Brands', icon: 'pi pi-fw pi-align-justify', command:() => this.gotoBrandList() },
      { label: 'Service', icon: 'pi pi-fw pi-cog', },
      {
        label: 'Brand', icon: 'pi pi-fw pi-car', items: [
          {
            label: 'Mercedes',
            icon: 'pi pi-fw pi-car',
           
          },
          {
            label: 'Porche',
            icon: 'pi pi-fw pi-car',
            command:() => this.gotoBrand("Porche")
          },
          {
            label: 'BMW',
            icon: 'pi pi-fw pi-car'
          },
          {
            label: 'Audi',
            icon: 'pi pi-fw pi-car'
          }
        ]
      },
      { label: 'About Us', icon: 'pi pi-fw pi-at' },
      { label: 'Store', icon: 'pi pi-home',  command:() => this.gotoStore() }
    ];

    this.activeItem = this.items[0];
    this.images = images;
  }
  gotoStore(){
    window.location.href = '/view-all-store';
  }
  gotoHome(){
    window.location.href = '/';
  }
  gotoList(){
    window.location.href = '/view-list-product';
  }
  gotoBrand(event :string){
    window.location.href = '/show-product-card/' + event;
  }
  gotoBrandList(){
    window.location.href = '/brand-management';
  }
  onActiveItemChange(event: MenuItem) {
    this.activeItem = event;
    if (this.activeItem.label === 'Home') {
      window.location.href = '/';
    }
    if (this.activeItem.label === 'Brand') {
      // window.location.href = '/view-list-product';
    }
    console.log(this.activeItem)
  }
}
