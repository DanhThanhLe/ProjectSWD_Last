import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Brand } from 'src/app/data/data-mocks/data-modal/brand-modal';
import { BrandService } from 'src/app/service/brand.service';

@Component({
  selector: 'app-brand-detail',
  templateUrl: './brand-detail.component.html',
  styleUrls: ['./brand-detail.component.scss']
})
export class BrandDetailComponent {
  id: any;
  brand!: Brand;

  constructor(private route: ActivatedRoute,
    private brandService: BrandService){}

    ngOnInit() {
  
      this.id = this.route.snapshot.params['id'];
      
      this.brandService.getBrandById(this.id)
        .subscribe(data => {
        this.brand = data.result;
        }, error => console.log(error));
    }


  list(){
    window.location.href = 'brand-management';
  }
}
