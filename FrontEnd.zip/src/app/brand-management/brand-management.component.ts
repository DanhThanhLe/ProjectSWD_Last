import { Component } from '@angular/core';
import { Brand } from '../data/data-mocks/data-modal/brand-modal';
import { BrandService } from '../service/brand.service';

@Component({
  selector: 'app-brand-management',
  templateUrl: './brand-management.component.html',
  styleUrls: ['./brand-management.component.scss']
})
export class BrandManagementComponent {
  public brandList!: Brand[];
  constructor( private brandService : BrandService) { }
  ngOnInit(): void {
    this.brandService.getBrandList().subscribe(data =>{
      this.brandList = data.items;
    }, error => console.log(error));
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
  }
  goToBrandDetail(id: any){
    window.location.href ='brand-detail/' + id;
  }
}
