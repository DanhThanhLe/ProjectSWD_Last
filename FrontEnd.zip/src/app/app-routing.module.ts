import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShowProductsComponentComponent } from './show-products-component/show-products-component.component';
import { ProductDetailComponentComponent } from './show-product-card-component/product-detail-component/product-detail-component.component';
import { HomePageComponentComponent } from './home-page-component/home-page-component.component';
import { ShowProductCardComponentComponent } from './show-product-card-component/show-product-card-component.component';
import { ViewAllStoreComponentComponent } from './view-all-store-component/view-all-store-component.component';
import { ProductViewDetailComponent } from './show-products-component/product-view-detail/product-view-detail.component';
import { BrandManagementComponent } from './brand-management/brand-management.component';
import { BrandDetailComponent } from './brand-management/brand-detail/brand-detail.component';

const routes: Routes = [
  {path: '', component: HomePageComponentComponent},
  {path: 'view-list-product', component: ShowProductsComponentComponent},
  {path: 'product-detail/:id', component: ProductDetailComponentComponent},
  {path: 'show-product-card/:brand', component: ShowProductCardComponentComponent},
  {path: 'view-all-store', component: ViewAllStoreComponentComponent},
  {path: 'product-view-detail/:id', component:ProductViewDetailComponent},
  {path: 'brand-management' , component: BrandManagementComponent},
  {path: 'brand-detail/:id', component:BrandDetailComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
