import { Component } from '@angular/core';
import { storeList } from '../data/data-mocks/stores';

@Component({
  selector: 'app-view-all-store-component',
  templateUrl: './view-all-store-component.component.html',
  styleUrls: ['./view-all-store-component.component.scss']
})
export class ViewAllStoreComponentComponent {
  listStore = storeList;
}
