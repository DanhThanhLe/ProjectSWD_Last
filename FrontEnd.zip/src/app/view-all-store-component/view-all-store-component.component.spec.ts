import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllStoreComponentComponent } from './view-all-store-component.component';

describe('ViewAllStoreComponentComponent', () => {
  let component: ViewAllStoreComponentComponent;
  let fixture: ComponentFixture<ViewAllStoreComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewAllStoreComponentComponent]
    });
    fixture = TestBed.createComponent(ViewAllStoreComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
