import { Store } from "./data-modal/store";

export const storeList  : Store[] = [
  {
    id: 1,
    storeName:"FPT Trường Chinh",
    location: "Cửa hàng FPT Shop Tại 306A Trường Chinh, P. 13, Q. Tân Bình, TP. Hồ Chí Minh",
    image: "../../../assets/fpt_truongchinh.jpg",
    email: " fptshop@fpt.com.vn",
    phone: "1800 6601"
},
{
  id: 2,
  storeName:"FPT Đà Nẵng",
  location: "Fptshop Đà Nẵng - 318 Lê Duẩn | Da Nang",
  image: "../../../assets/fpt_Danang.jpg",
  email: " fptshop@fpt.com.vn",
  phone: "1800 6601"
},
{
  id: 3,
  storeName:"FPT Hà Nội",
  location: "Cửa hàng FPT Shop Tại Số 1 Vĩnh Hưng (Ngã 3 Vĩnh Hưng-Lĩnh Nam), P. Vĩnh Hưng, Q. Hoàng Mai, TP. Hà Nội",
  image: "../../../assets/fpt_hanoi.jpg",
  email: " fptshop@fpt.com.vn",
  phone: "1800 6601"
},
{
  id: 4,
  storeName:"FPT Cần Thơ",
  location: "Cửa hàng FPT Shop Tại 83 Trần Hưng Đạo, Phường An Phú, Quận Ninh Kiều, Thành Phố Cần Thơ, Việt Nam ",
  image: "../../../assets/fpt_cantho.jpg",
  email: " fptshop@fpt.com.vn",
  phone: "1800 6601"
}]
