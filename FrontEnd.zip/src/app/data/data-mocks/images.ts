export const  images : any[] = [
  {
    itemImageSrc: '../../../assets/718-Boxster-S-718-Cayman-S-1600x615.jpg',
    thumbnailImageSrc: 'https://primefaces.org/cdn/primeng/images/galleria/galleria1s.jpg',
    alt: 'Description for Image 1',
    title: 'Title 1'
},
{
   itemImageSrc: '../../../assets/rd-2021-homepage-banner-pcna-macanii-kw29--1600x615.jpg',
    thumbnailImageSrc: 'https://primefaces.org/cdn/primeng/images/galleria/galleria2s.jpg',
    alt: 'Description for Image 2',
    title: 'Title 2'
},
{
  itemImageSrc: '../../../assets/rd-2021-homepage-banner-ww-e3topgt-kw26-1600x615.jpg',
    thumbnailImageSrc: 'https://primefaces.org/cdn/primeng/images/galleria/galleria3s.jpg',
    alt: 'Description for Image 3',
    title: 'Title 3'
},
{
  itemImageSrc: '../../../assets/rd-2022µ20-homepage-banner-ww-992dakar-kw46-1600x615.jpg',
    thumbnailImageSrc: 'https://primefaces.org/cdn/primeng/images/galleria/galleria4s.jpg',
    alt: 'Description for Image 4',
    title: 'Title 4'
},
{
  itemImageSrc: '../../../assets/RD-2023-Homepage-Banner-WW-TaycanPushGTS-KW19-1600x615.jpg',
    thumbnailImageSrc: 'https://primefaces.org/cdn/primeng/images/galleria/galleria5s.jpg',
    alt: 'Description for Image 5',
    title: 'Title 5'
}
]
