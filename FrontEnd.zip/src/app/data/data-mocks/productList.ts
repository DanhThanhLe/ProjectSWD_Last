import { Product } from "./data-modal/product";

export const productList  : Product[] = [
  {
    id: 1,
    productName:"Porsche",
    price: 5000,
    status: "New",
    image: "../../../assets/911.png",
    description: "Is a Vip Car",
    creatationDate: "27-07-2023",
    createBy: "HungLD",
    deletionDate: "30-07-2023",
    deleteBy: "SuuTV"
},
{
  id: 2,
  productName:"Mercs",
  price: 5000,
  status: "New",
  image: "../../../assets/911T.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 3,
  productName:"Suv",
  price: 5000,
  status: "New",
  image: "../../../assets/911GTS.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 4,
  productName:"BMW",
  price: 5000,
  status: "New",
  image: "../../../assets/911GTS Cab.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 5,
  productName:"Ferrari",
  price: 5000,
  status: "New",
  image: "../../../assets/911Cab.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 6,
  productName:"G63",
  price: 5000,
  status: "New",
  image: "../../../assets/911_4_GTS.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 8,
  productName:"Maybach",
  price: 5000,
  status: "New",
  image: "../../../assets/911_4_cab.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
},
{
  id: 9,
  productName:"Panamera",
  price: 5000,
  status: "New",
  image: "../../../assets/911_4.png",
  description: "Is a Vip Car",
  creatationDate: "27-07-2023",
  createBy: "HungLD",
  deletionDate: "30-07-2023",
  deleteBy: "SuuTV"
}
]
