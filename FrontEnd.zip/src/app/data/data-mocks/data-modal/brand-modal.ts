export interface Brand{
    id:	string,
    brandName:string,
    address:string,
    hotline:string,
    description:string,
    creationDate:string,
    createdBy:string,
    deletionDate:string,
    deleteBy:string
    }