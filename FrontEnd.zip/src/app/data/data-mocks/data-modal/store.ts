export interface Store {
  id: number,
  storeName:string,
  location: string,
  image: string,
  email: string,
  phone: string
}
