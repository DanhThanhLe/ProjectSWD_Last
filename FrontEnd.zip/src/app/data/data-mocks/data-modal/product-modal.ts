export interface ProductModal {
    id: number,
    productName:string,
    price: number,
    status: number,
    description: string,
    creatationDate: string,
    createBy: string,
    deletionDate: string,
    deleteBy: string
  }
  