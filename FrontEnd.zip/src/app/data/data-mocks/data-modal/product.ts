export interface Product {
  id: number,
  productName:string,
  price: number,
  status: string,
  image: string,
  description: string,
  creatationDate: string,
  createBy: string,
  deletionDate: string,
  deleteBy: string
}
