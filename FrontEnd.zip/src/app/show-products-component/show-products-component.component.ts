import { Component } from '@angular/core';
import { productList } from './../data/data-mocks/productList';
import { Product } from '../data/data-mocks/data-modal/product';
import {ProductService} from '../service/product.service';

@Component({
  selector: 'app-show-products-component',
  templateUrl: './show-products-component.component.html',
  styleUrls: ['./show-products-component.component.scss']
})
export class ShowProductsComponentComponent {
  public productList!: Product[];
  constructor( private productService : ProductService) { }
  ngOnInit(): void {
    this.productService.getProductsList().subscribe(data =>{
      this.productList = data.items;
    }, error => console.log(error));
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
  }
  goToProductDetail(id: any){
    window.location.href ='product-view-detail/' + id;
  }
}
