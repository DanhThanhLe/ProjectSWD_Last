import { Component } from '@angular/core';
import { ProductModal } from 'src/app/data/data-mocks/data-modal/product-modal';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/service/product.service';
@Component({
  selector: 'app-product-view-detail',
  templateUrl: './product-view-detail.component.html',
  styleUrls: ['./product-view-detail.component.scss']
})
export class ProductViewDetailComponent {
  id: any;
  product!: ProductModal;
  editModalVisible: boolean = false;

  constructor(private route: ActivatedRoute,
    private productService: ProductService){}

    ngOnInit() {
  
      this.id = this.route.snapshot.params['id'];
      
      this.productService.getProductById(this.id)
        .subscribe(data => {
        this.product = data.result;
        }, error => console.log(error));
    }

    list(){
      window.location.href = 'view-list-product';
    }
    showEditDialog(){
      this.editModalVisible = true;
    }
    onEdit(){
      this.updateProduct();
      this.editModalVisible = false;
    }
    updateProduct() {
      this.productService.updateProduct(this.id, this.product)
        .subscribe(data => {
        }, error => 
        alert(error.error.text));
    }
}
