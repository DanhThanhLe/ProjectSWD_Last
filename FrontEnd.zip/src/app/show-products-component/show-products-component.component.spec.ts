import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowProductsComponentComponent } from './show-products-component.component';

describe('ShowProductsComponentComponent', () => {
  let component: ShowProductsComponentComponent;
  let fixture: ComponentFixture<ShowProductsComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ShowProductsComponentComponent]
    });
    fixture = TestBed.createComponent(ShowProductsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
