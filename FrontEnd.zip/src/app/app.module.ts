import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ToolbarModule } from 'primeng/toolbar';
import { DividerModule } from 'primeng/divider';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { TabMenuModule } from 'primeng/tabmenu';
import { CarouselModule } from 'primeng/carousel';
import { GalleriaModule } from 'primeng/galleria';
import { TimelineModule } from 'primeng/timeline';
import { CardModule } from 'primeng/card';
import { MenubarModule } from 'primeng/menubar';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ShowProductsComponentComponent } from './show-products-component/show-products-component.component';
import { ProductDetailComponentComponent } from './show-product-card-component/product-detail-component/product-detail-component.component';
import { HomePageComponentComponent } from './home-page-component/home-page-component.component';
import { ShowProductCardComponentComponent } from './show-product-card-component/show-product-card-component.component';
import { ViewAllStoreComponentComponent } from './view-all-store-component/view-all-store-component.component';
import { ProductViewDetailComponent } from './show-products-component/product-view-detail/product-view-detail.component';
import { BrandManagementComponent } from './brand-management/brand-management.component';
import { BrandDetailComponent } from './brand-management/brand-detail/brand-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    ShowProductsComponentComponent,
    ProductDetailComponentComponent,
    HomePageComponentComponent,
    ShowProductCardComponentComponent,
    ViewAllStoreComponentComponent,
    ProductViewDetailComponent,
    BrandManagementComponent,
    BrandDetailComponent
  ],
  imports: [
    BrowserModule,
    ToolbarModule,
    ButtonModule,
    TableModule,
    DividerModule,
    TabMenuModule,
    CarouselModule,
    GalleriaModule,
    TimelineModule,
    CardModule,
    MenubarModule,
    HttpClientModule,
    DialogModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
