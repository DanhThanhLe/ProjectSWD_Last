﻿using Application.ViewModels.RoleViewModels;
using FluentValidation;

namespace Project_SWD.Validations.RoleValidation
{
    public class UpdateRoleValidation : AbstractValidator<UpdateRoleViewModel>
    {
        public UpdateRoleValidation()
        {
            RuleFor(x => x.RoleName).NotEmpty().NotNull().MaximumLength(100);
        }
    }
}
