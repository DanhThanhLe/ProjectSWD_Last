﻿using Application.ViewModels.RoleViewModels;
using FluentValidation;

namespace Project_SWD.Validations.RoleValidation
{
    public class CreateRoleValidation : AbstractValidator<CreateRoleViewModel>
    {
        public CreateRoleValidation()
        {
            RuleFor(x => x.RoleName).NotEmpty().NotNull().MaximumLength(100);

        }

    }
}
