﻿using Application.Commos;
using Application.Interfaces;
using Application.ViewModels.ProductViewModels;
using Application.ViewModels.RoleViewModels;
using Applications.ViewModels.Response;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Project_SWD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IProductService _productServices;
        private readonly IRoleService _roleServices;
        private readonly IValidator<CreateRoleViewModel> _validatorCreate;
        private readonly IValidator<UpdateRoleViewModel> _validatorUpdate;
        public RoleController(IProductService productServices, IRoleService roleServices,
            IValidator<CreateRoleViewModel> validatorCreate, IValidator<UpdateRoleViewModel> validatorUpdate
            )
        {
            _productServices = productServices;
            _roleServices = roleServices;
            _validatorCreate = validatorCreate;
            _validatorUpdate = validatorUpdate;
        }
        [HttpPost("CreateRole")]
        public async Task<Response> CreateRole(CreateRoleViewModel RoleModel)
        {
            if (ModelState.IsValid)
            {
                ValidationResult validation = _validatorCreate.Validate(RoleModel);
                if (validation.IsValid)
                {
                    await _roleServices.CreateRole(RoleModel);
                    return new Response(HttpStatusCode.OK, "Create Role Succeed", RoleModel);
                }
            }
            else
            {
                return new Response(HttpStatusCode.BadRequest, "Create Failed, Invalid input");
            }
            return new Response(HttpStatusCode.BadRequest, "Invalid Input");
        }

        [HttpGet("GetAllRoles")]
        public async Task<Pagination<RoleViewModel>> GetAllRoles(int pageIndex = 0, int pageSize = 10) => await _roleServices.GetAllRoles(pageIndex, pageSize);


        [HttpGet("GetRoleByName/{RoleName}")]
        public async Task<Response> GetRoleByName(string RoleName, int pageIndex = 0, int pageSize = 10)
        {
            return await _roleServices.GetRoleByName(RoleName, pageIndex, pageSize);
        }

        [HttpGet("GetRoleById/{RoleId}")]
        public async Task<Response> GetRoleById(Guid RoleId) => await _roleServices.GetRoleById(RoleId);

        [HttpPut("UpdateRole/{RoleId}")]
        public async Task<IActionResult> UpdateRole(Guid RoleId, UpdateRoleViewModel Role)
        {
            if (ModelState.IsValid)
            {
                ValidationResult result = _validatorUpdate.Validate(Role);
                if (result.IsValid)
                {
                    if (await _roleServices.UpdateRole(RoleId, Role) != null)
                    {
                        return Ok("Update Role Success");
                    }
                    return BadRequest("Invalid Id");
                }
            }
            return BadRequest("Update Failed,Invalid Input Information");
        }
    }
}
