﻿using Application.Commos;
using Application.Interfaces;
using Application.ViewModels.RoleViewModels;
using Applications;
using Applications.ViewModels.Response;
using AutoMapper;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class RoleService : IRoleService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        public RoleService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<CreateRoleViewModel> CreateRole(CreateRoleViewModel roleDTO)
        {
            var productObj = _mapper.Map<Role>(roleDTO);
            await _unitOfWork.RoleRepository.AddAsync(productObj);
            var isSuccess = await _unitOfWork.SaveChangeAsync() > 0;
            if (isSuccess)
            {
                return _mapper.Map<CreateRoleViewModel>(productObj);
            }
            return null;
        }

        public async Task<Pagination<RoleViewModel>> GetAllRoles(int pageIndex = 0, int pageSize = 10)
        {
            var roles = await _unitOfWork.RoleRepository.ToPagination(pageIndex, pageSize);
            var result = _mapper.Map<Pagination<RoleViewModel>>(roles);
            var guidList = roles.Items.Select(x => x.CreatedBy).ToList();
            var users = await _unitOfWork.UserRepository.GetEntitiesByIdsAsync(guidList);

            foreach (var item in result.Items)
            {
                if (string.IsNullOrEmpty(item.CreatedBy)) continue;

                var createdBy = users.FirstOrDefault(x => x.Id == Guid.Parse(item.CreatedBy));
                if (createdBy != null)
                {
                    item.CreatedBy = createdBy.Email;
                }
            }
            return result;
        }

        public async Task<Response> GetRoleById(Guid RoleId)
        {
            var roles = await _unitOfWork.RoleRepository.GetByIdAsync(RoleId);
            var result = _mapper.Map<RoleViewModel>(roles);
            var createBy = await _unitOfWork.UserRepository.GetByIdAsync(roles.CreatedBy);
            if (createBy != null)
            {
                result.CreatedBy = createBy.Email;
            }
            if (roles == null) return new Response(HttpStatusCode.NoContent, "Id not found");
            else return new Response(HttpStatusCode.OK, "Search succeed", result);
        }

        public async Task<Response> GetRoleByName(string RoleName, int pageIndex = 0, int pageSize = 10)
        {
            var products = await _unitOfWork.RoleRepository.GetRoleByName(RoleName, pageIndex, pageSize);
            if (products.Items.Count() < 1) return new Response(HttpStatusCode.NoContent, "Not Found");
            else return new Response(HttpStatusCode.OK, "Search Succeed", _mapper.Map<Pagination<RoleViewModel>>(products));
        }

        public async Task<UpdateRoleViewModel> UpdateRole(Guid RoleId, UpdateRoleViewModel roleDTO)
        {
            var RoleObj = await _unitOfWork.RoleRepository.GetByIdAsync(RoleId);
            if (RoleObj != null)
            {
                _mapper.Map(roleDTO, RoleObj);
                _unitOfWork.RoleRepository.Update(RoleObj);
                var isSuccess = await _unitOfWork.SaveChangeAsync() > 0;
                if (isSuccess)
                {
                    return _mapper.Map<UpdateRoleViewModel>(RoleObj);
                }
            }
            return null;
        }
    }
}
