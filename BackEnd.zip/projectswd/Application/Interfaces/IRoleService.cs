﻿using Application.Commos;
using Application.ViewModels.ProductViewModels;
using Application.ViewModels.RoleViewModels;
using Applications.ViewModels.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IRoleService
    {
        public Task<CreateRoleViewModel> CreateRole(CreateRoleViewModel roleDTO);
        public Task<UpdateRoleViewModel> UpdateRole(Guid RoleId, UpdateRoleViewModel roleDTO);
        public Task<Pagination<RoleViewModel>> GetAllRoles(int pageIndex = 0, int pageSize = 10);
        public Task<Response> GetRoleByName(string RoleName, int pageIndex = 0, int pageSize = 10);
        public Task<Response> GetRoleById(Guid RoleId);
    }
}
