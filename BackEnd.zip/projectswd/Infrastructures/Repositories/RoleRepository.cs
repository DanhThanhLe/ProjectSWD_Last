﻿using Application.Commos;
using Application.Repositories;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructures.Repositories
{
    public class RoleRepository : GenericRepository<Role>, IRoleRepository
    {
        private readonly AppDBContext _dbContext;
        public RoleRepository(AppDBContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Pagination<Role>> GetRoleByName(string RoleName, int pageNumber = 0, int pageSize = 10)
        {
            var itemCount = await _dbContext.Roles.CountAsync();
            var items = await _dbContext.Roles.Where(x => x.RoleName.Contains(RoleName))
                                    .OrderByDescending(x => x.CreationDate)
                                    .Skip(pageNumber * pageSize)
                                    .Take(pageSize)
                                    .AsNoTracking()
                                    .ToListAsync();

            var result = new Pagination<Role>()
            {
                PageIndex = pageNumber,
                PageSize = pageSize,
                TotalItemsCount = itemCount,
                Items = items,
            };
            return result;
        }

        public async Task<Guid> GetRoleIdByName(string RoleName)
        {
            var roleId = await _dbContext.Roles.Where(x => x.RoleName == RoleName).Select(x => x.Id).FirstOrDefaultAsync();
            return roleId;
        }
    }
}
